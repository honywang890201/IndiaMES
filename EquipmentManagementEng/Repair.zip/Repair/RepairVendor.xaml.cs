﻿using Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Repair
{
    /// <summary>
    /// Repair.xaml 的交互逻辑
    /// </summary>
    public partial class RepairVendor : Component.Controls.User.UserVendor
    {
        private string setting_path = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, Framework.SysVar.SETTING_FILE_NAME);
        private DataTable RepairInSource = null;
        private bool _IsRepair = false;
        private bool IsRepair
        {
            get
            {
                return _IsRepair;
            }
            set
            {
                _IsRepair = value;

                if (_IsRepair)
                {
                    gridCommand.Visibility = Visibility.Visible;
                }
                else
                {
                    gridCommand.Visibility = Visibility.Collapsed;
                }
            }
        }
        private long LotId = 0;
        private long? RepairInId = null;
        private string LotSN = null;
        private string LotSNType = null;

        private long? WorkflowId = null;
        private bool IsComplete = false;
        private bool IsScrap = false;
        private bool IsErrorInStore = false;

        private string MoCode = null;
        private string OrderCode = null;
        private string ItemCode = null;
        private string ItemDesc = null;
        private string LineName = null;
        private string WorkflowStationCode = null;

        private bool InputRepairErrorReason = true;
        private bool InputRepairErrorLocation = true;
        private bool InputRepairErrorPoints = true;
        private bool InputRepairErrorDuty = true;
        private bool InputRepairErrorSolution = true;
        private bool InputRepairContent = true;
        private bool InputRepairErrorNote = true;

        private void GetConfig()
        {
            string temp;
            try
            {
                temp = WinAPI.File.INIFileHelper.Read("Repair", "InputRepairErrorReason", setting_path);
                if (!string.IsNullOrEmpty(temp))
                {
                    if (!bool.TryParse(temp, out InputRepairErrorReason))
                    {
                        InputRepairErrorReason = true;
                    }
                }
            }
            catch { }


            try
            {
                temp = WinAPI.File.INIFileHelper.Read("Repair", "InputRepairErrorLocation", setting_path);
                if (!string.IsNullOrEmpty(temp))
                {
                    if (!bool.TryParse(temp, out InputRepairErrorLocation))
                    {
                        InputRepairErrorLocation = true;
                    }
                }
            }
            catch { }


            try
            {
                temp = WinAPI.File.INIFileHelper.Read("Repair", "InputRepairErrorPoints", setting_path);
                if (!string.IsNullOrEmpty(temp))
                {
                    if (!bool.TryParse(temp, out InputRepairErrorPoints))
                    {
                        InputRepairErrorPoints = true;
                    }
                }
            }
            catch { }


            try
            {
                temp = WinAPI.File.INIFileHelper.Read("Repair", "InputRepairErrorDuty", setting_path);
                if (!string.IsNullOrEmpty(temp))
                {
                    if (!bool.TryParse(temp, out InputRepairErrorDuty))
                    {
                        InputRepairErrorDuty = true;
                    }
                }
            }
            catch { }


            try
            {
                temp = WinAPI.File.INIFileHelper.Read("Repair", "InputRepairErrorSolution", setting_path);
                if (!string.IsNullOrEmpty(temp))
                {
                    if (!bool.TryParse(temp, out InputRepairErrorSolution))
                    {
                        InputRepairErrorSolution = true;
                    }
                }
            }
            catch { }


            try
            {
                temp = WinAPI.File.INIFileHelper.Read("Repair", "InputRepairContent", setting_path);
                if (!string.IsNullOrEmpty(temp))
                {
                    if (!bool.TryParse(temp, out InputRepairContent))
                    {
                        InputRepairContent = true;
                    }
                }
            }
            catch { }


            try
            {
                temp = WinAPI.File.INIFileHelper.Read("Repair", "InputRepairErrorNote", setting_path);
                if (!string.IsNullOrEmpty(temp))
                {
                    if (!bool.TryParse(temp, out InputRepairErrorNote))
                    {
                        InputRepairErrorNote = true;
                    }
                }
            }
            catch { }
        }

        private void SetRepairFocus(Component.Controls.User.GenerateControl.GenerateBase element, bool IsEnter)
        {
            List<Component.Controls.User.GenerateControl.GenerateBase> l = new List<Component.Controls.User.GenerateControl.GenerateBase>();
            if (cmbRepairErrorReason.Visibility == Visibility.Visible)
            {
                l.Add(cmbRepairErrorReason);
            }
            if (tbRepairErrorLocation.Visibility == Visibility.Visible)
            {
                l.Add(tbRepairErrorLocation);
            }
            if (tbRepairErrorPoints.Visibility == Visibility.Visible)
            {
                l.Add(tbRepairErrorPoints);
            }
            if (cmbRepairErrorDuty.Visibility == Visibility.Visible)
            {
                l.Add(cmbRepairErrorDuty);
            }
            if (cmbRepairErrorSolution.Visibility == Visibility.Visible)
            {
                l.Add(cmbRepairErrorSolution);
            }

            if (IsEnter)
            {
                int index = l.IndexOf(element);
                if (index >= 0)
                {
                    if (index >= l.Count - 1)
                    {
                        btnSave_Click(element, null);
                    }
                    else
                    {
                        l[index + 1].SetFoucs();
                    }
                }
                else
                {
                    btnSave_Click(element, null);
                }
            }
            else
            {
                if (l.Count > 0)
                {
                    l[0].SetFoucs();
                }
                else
                {
                   // btnSave_Click(element, null);
                }
            }
        }

        public RepairVendor(Framework.SystemAuthority authority) :
            base(authority)
        {
            InitializeComponent();
            GetConfig();



            this.KeyDown += new KeyEventHandler((sender, e) =>
            {
                if (e.Key == System.Windows.Input.Key.S && (System.Windows.Input.Keyboard.Modifiers & (System.Windows.Input.ModifierKeys.Control)) == (System.Windows.Input.ModifierKeys.Control))
                {
                    if (IsRepair)
                    {
                        if (IsRepairErrorCode)
                        {
                            btnSave_Click(btnSave, null);
                            e.Handled = true;
                        }
                    }
                }


                if (e.Key == System.Windows.Input.Key.D && (System.Windows.Input.Keyboard.Modifiers & (System.Windows.Input.ModifierKeys.Control)) == (System.Windows.Input.ModifierKeys.Control))
                {
                    if (IsRepair)
                    {
                        if (!IsRepairErrorCode)
                        {
                            btnRepairComplete_Click(btnRepairComplete, null);
                            e.Handled = true;
                        }
                    }
                }
            });

            if (!Framework.App.Resource.ResourceId.HasValue || !Framework.App.Resource.StationId.HasValue)
            {
                Component.MessageBox.MyMessageBox.ShowError("没有获取到工序，不能维修作业，请尝试使用正确的资源重新登录程序。");
                this.IsEnabled = false;
                return;
            }
            //if (!Framework.App.Resource.ShiftTypeId.HasValue)
            //{
            //    Component.MessageBox.MyMessageBox.ShowError("没有获取到班制，不能维修作业，请尝试使用正确的资源重新登录程序。");
            //    this.IsEnabled = false;
            //    return;
            //}
            tbSN.KeyDown += new KeyEventHandler((sender, e) =>
            {
                if (e.Key == Key.Enter)
                {
                    bdQuery_MouseDown(tbSN, null);
                    e.Handled = true;
                }
            });

            LoadcmbSource();
            LoadWorkflow();
            ckbReWorkflow.Unchecked += new RoutedEventHandler((sender, e) =>
            {
                if (IsRepair && IsComplete)
                {
                    Component.MessageBox.MyMessageBox.ShowWarning("已完工产品维修必须重新指定工作流");
                    ckbReWorkflow.IsChecked = true;
                }
                else if ((IsRepair && !WorkflowId.HasValue))
                {
                    Component.MessageBox.MyMessageBox.ShowWarning(string.Format("产品[{0}]的工作流为空，需要手工指定工作流", LotSN));
                    ckbReWorkflow.IsChecked = true;
                }
                else
                {
                    cmbWorkflow.Visibility = Visibility.Collapsed;
                    LoadStation();
                }
            });
            ckbReWorkflow.Checked += new RoutedEventHandler((sender, e) =>
            {
                cmbWorkflow.Visibility = Visibility.Visible;
                ckbReStation.IsChecked = true;
                LoadStation();
            });
            ckbReStation.Unchecked += new RoutedEventHandler((sender, e) =>
            {
                if (IsRepair && IsComplete)
                {
                    Component.MessageBox.MyMessageBox.ShowWarning("已完工产品维修必须重新指定工序");
                    ckbReStation.IsChecked = true;
                }
                else if ((IsRepair && !WorkflowId.HasValue))
                {
                    Component.MessageBox.MyMessageBox.ShowWarning(string.Format("产品[{0}]的工作流为空，需要手工指定工序", LotSN));
                    ckbReStation.IsChecked = true;
                }
                else if (ckbReWorkflow.IsChecked.Value)
                {
                    Component.MessageBox.MyMessageBox.ShowWarning(string.Format("当重新指定工作流后，必须重新指定工序"));
                    ckbReStation.IsChecked = true;
                }
                else
                {
                    cmbStation.Visibility = Visibility.Collapsed;
                }
            });
            ckbReStation.Checked += new RoutedEventHandler((sender, e) =>
            {
                cmbStation.Visibility = Visibility.Visible;
                LoadStation();
            });
            ckbIsScrape.Checked += new RoutedEventHandler((sender, e) =>
            {
                ckbIsErrorInStore.IsChecked = false;
                ckbReWorkflow.Visibility = Visibility.Collapsed;
                cmbWorkflow.Visibility = Visibility.Collapsed;
                ckbReStation.Visibility = Visibility.Collapsed;
                cmbStation.Visibility = Visibility.Collapsed;
                LoadStation();
            });
            ckbIsScrape.Unchecked += new RoutedEventHandler((sender, e) =>
            {
                if (!ckbIsErrorInStore.IsChecked.HasValue || !ckbIsErrorInStore.IsChecked.Value)
                {
                    ckbReWorkflow.Visibility = Visibility.Visible;
                    cmbWorkflow.Visibility = ckbReWorkflow.IsChecked.Value ? Visibility.Visible : Visibility.Collapsed;
                    ckbReStation.Visibility = Visibility.Visible;
                    cmbStation.Visibility = ckbReStation.IsChecked.Value ? Visibility.Visible : Visibility.Collapsed;
                }
            });
            ckbIsErrorInStore.Checked += new RoutedEventHandler((sender, e) =>
            {
                ckbIsScrape.IsChecked = false;
                ckbReWorkflow.Visibility = Visibility.Collapsed;
                cmbWorkflow.Visibility = Visibility.Collapsed;
                ckbReStation.Visibility = Visibility.Collapsed;
                cmbStation.Visibility = Visibility.Collapsed;
                LoadStation();
            });
            ckbIsErrorInStore.Unchecked += new RoutedEventHandler((sender, e) =>
            {
                if (!ckbIsScrape.IsChecked.HasValue || !ckbIsScrape.IsChecked.Value)
                {
                    ckbReWorkflow.Visibility = Visibility.Visible;
                    cmbWorkflow.Visibility = ckbReWorkflow.IsChecked.Value ? Visibility.Visible : Visibility.Collapsed;
                    ckbReStation.Visibility = Visibility.Visible;
                    cmbStation.Visibility = ckbReStation.IsChecked.Value ? Visibility.Visible : Visibility.Collapsed;
                }
            });
            ckbLock.Checked += new RoutedEventHandler((sender, e) =>
            {
                ckbIsErrorInStore.IsEnabled = false;
                ckbIsScrape.IsEnabled = false;
                ckbReWorkflow.IsEnabled = false;
                ckbReStation.IsEnabled = false;
                cmbWorkflow.IsEnabled = false;
                cmbStation.IsEnabled = false;
            });
            ckbLock.Unchecked += new RoutedEventHandler((sender, e) =>
            {
                ckbIsErrorInStore.IsEnabled = true;
                ckbIsScrape.IsEnabled = true;
                ckbReWorkflow.IsEnabled = true;
                ckbReStation.IsEnabled = true;
                cmbWorkflow.IsEnabled = true;
                cmbStation.IsEnabled = true;
            });

            cmbRepairErrorReason.KeyDown += new KeyEventHandler((sender, e) =>
            {
                if (e.Key == Key.Enter)
                {
                    SetRepairFocus(cmbRepairErrorReason, true);
                }
            });
            tbRepairErrorLocation.KeyDown += new KeyEventHandler((sender, e) =>
            {
                if (e.Key == Key.Enter)
                {
                    SetRepairFocus(tbRepairErrorLocation, true);
                }
            });
            tbRepairErrorPoints.KeyDown += new KeyEventHandler((sender, e) =>
            {
                if (e.Key == Key.Enter)
                {
                    SetRepairFocus(tbRepairErrorPoints, true);
                }
            });
            cmbRepairErrorDuty.KeyDown += new KeyEventHandler((sender, e) =>
            {
                if (e.Key == Key.Enter)
                {
                    SetRepairFocus(cmbRepairErrorDuty, true);
                }
            });
            cmbRepairErrorSolution.KeyDown += new KeyEventHandler((sender, e) =>
            {
                if (e.Key == Key.Enter)
                {
                    SetRepairFocus(cmbRepairErrorSolution, true);
                }
            });


            ckbLock.IsChecked = false;
            ckbIsErrorInStore.IsChecked = false;
            ckbIsScrape.IsChecked = false;
            SetUISourceLoad();

            this.Loaded += new RoutedEventHandler((sender, e) => { tbSN.SetFoucs(); });

            if (!InputRepairErrorReason)
            {
                rtRepairErrorReason1.Visibility = Visibility.Collapsed;
                lblRepairErrorReason.Visibility = Visibility.Collapsed;
                cmbRepairErrorReason.Visibility = Visibility.Collapsed;
                rtRepairErrorReason.Visibility = Visibility.Collapsed;
            }
            if (!InputRepairErrorLocation)
            {
                rtRepairErrorLocation1.Visibility = Visibility.Collapsed;
                lblRepairErrorLocation.Visibility = Visibility.Collapsed;
                tbRepairErrorLocation.Visibility = Visibility.Collapsed;
                rtRepairErrorLocation.Visibility = Visibility.Collapsed;
            }
            if (!InputRepairErrorPoints)
            {
                rtRepairErrorPoints1.Visibility = Visibility.Collapsed;
                lblRepairErrorPoints.Visibility = Visibility.Collapsed;
                tbRepairErrorPoints.Visibility = Visibility.Collapsed;
                rtRepairErrorPoints.Visibility = Visibility.Collapsed;
            }
            if (!InputRepairErrorDuty)
            {
                rtRepairErrorDuty1.Visibility = Visibility.Collapsed;
                lblRepairErrorDuty.Visibility = Visibility.Collapsed;
                cmbRepairErrorDuty.Visibility = Visibility.Collapsed;
                rtRepairErrorDuty.Visibility = Visibility.Collapsed;
            }
            if (!InputRepairErrorSolution)
            {
                rtRepairErrorSolution1.Visibility = Visibility.Collapsed;
                lblRepairErrorSolution.Visibility = Visibility.Collapsed;
                cmbRepairErrorSolution.Visibility = Visibility.Collapsed;
                rtRepairErrorSolution.Visibility = Visibility.Collapsed;
            }
            if (!InputRepairContent)
            {
                rtRepairContent1.Visibility = Visibility.Collapsed;
                lblRepairContent.Visibility = Visibility.Collapsed;
                tbRepairContent.Visibility = Visibility.Collapsed;
                rtRepairContent.Visibility = Visibility.Collapsed;
            }
            if (!InputRepairErrorNote)
            {
                rtRepairErrorNote1.Visibility = Visibility.Collapsed;
                lblRepairErrorNote.Visibility = Visibility.Collapsed;
                tbRepairErrorNote.Visibility = Visibility.Collapsed;
                rtRepairErrorNote.Visibility = Visibility.Collapsed;
            }
        }

        private void SetUISourceLoad()
        {
            tbRepairSN.Text = "";
            tbOrder.Text = "";
            tbRepairMO.Text = "";
            tbRepairItem.Text = "";
            tbRepairError.Text = "";
            tbRepairErrorType.Text = "";
            tbRepairInputStation.Text = "";
            tbRepairInputLine.Text = "";
            tbRepairInputUser.Text = "";


            ClearRepairInfo();
            gridHistory.ItemsSource = null;
            gridRepairIn.ItemsSource = null;
            epdRepair.Visibility = Visibility.Collapsed;
            gridCommand.Visibility = Visibility.Collapsed;
            if (!ckbLock.IsChecked.Value)
            {
                ckbReWorkflow.IsChecked = false;
                ckbReStation.IsChecked = false;
                ckbIsScrape.IsChecked = false;
                ckbIsErrorInStore.IsChecked = false;
            }
            IsRepair = false;
            LotId = 0;
            LotSN = null;
            LotSNType = null;
            WorkflowId = null;
            RepairInId = null;
            IsScrap = false;
            IsComplete = false;
            IsErrorInStore = false;
            IsRepairErrorCode = false;
            RepairIn_ItemsId = null;
            AddMessage("就绪", false);

            MoCode = null;
            ItemCode = null;
            ItemDesc = null;
            LineName = null;
            WorkflowStationCode = null;

            btnSave.Visibility = Visibility.Collapsed;
            btnCancel.Visibility = Visibility.Collapsed;
            btnRepairComplete.Visibility = Visibility.Visible;
            btnAddError.Visibility = Visibility.Visible;
            gridLock.Visibility = Visibility.Visible;
        }

        private bool Clear(bool IsNoTip)
        {
            if (!IsNoTip)
            {
                if (IsRepair)
                {
                    if (Component.MessageBox.MyMessageBox.Show(string.Format("正在维修产品[{0}],确定放弃维修吗？", LotSN), "提示",
                                MessageBoxButton.OKCancel, MessageBoxImage.Warning) == System.Windows.MessageBoxResult.Cancel)
                    {
                        return false;
                    }
                }
            }
            IsRepair = false;
            SetUISourceLoad();


            return true;
        }

        private void AddMessage(string message, bool IsError)
        {
            tbMessage.Text = message;
            if (IsError)
            {
                tbMessage.Foreground = new SolidColorBrush(Colors.Red);
            }
            else
            {
                tbMessage.Foreground = new SolidColorBrush(Colors.Green);
            }
        }

        private void LoadcmbSource()
        {
            string sql;
            DataTable source = null;
            Dictionary<string, string> language = new Dictionary<string, string>();


            sql = @"SELECT Bas_ErrorReason.ErrorReasonId AS ReasonId,
	   Bas_ErrorReason.ErrorReasonCode+'/'+ISNULL(Bas_ErrorReason.ErrorReasonDesc,'') AS ReasonName,
	   Bas_ErrorReasonGroup.ErrorReasonGroupCode+'/'+ISNULL(Bas_ErrorReasonGroup.ErrorReasonGroupDesc,'') AS ReasonGroupName
FROM dbo.Bas_ErrorReason  WITH(NOLOCK) 
LEFT JOIN dbo.Bas_ErrorReasonGroup  WITH(NOLOCK) ON dbo.Bas_ErrorReasonGroup.ErrorReasonGroupId = dbo.Bas_ErrorReason.ErrorReasonGroupId
ORDER BY Bas_ErrorReason.ErrorReasonCode";

            try
            {
                source = DB.DBHelper.GetDataTable(sql, null, ExecuteType.Text);
                language.Clear();
                language.Add("ReasonName", "不良原因");
                language.Add("ReasonGroupName", "不良原因组");
                cmbRepairErrorReason.SetDataSource(source, language, true);
            }
            catch (Exception ex)
            {
                Component.MessageBox.MyMessageBox.ShowError(string.Format("加载不良原因错误：{0}", ex.Message));
                return;
            }


            sql = @"SELECT DutyId AS DutyId,
	   DutyCode+'/'+ISNULL(DutyDesc,'') AS DutyName
FROM dbo.Bas_Duty  WITH(NOLOCK) 
ORDER BY DutyCode";

            try
            {
                source = DB.DBHelper.GetDataTable(sql, null, ExecuteType.Text);
                language.Clear();
                language.Add("DutyName", "责任别");
                cmbRepairErrorDuty.SetDataSource(source, language, true);
            }
            catch (Exception ex)
            {
                Component.MessageBox.MyMessageBox.ShowError(string.Format("加载责任别错误：{0}", ex.Message));
                return;
            }


            sql = @"SELECT SolutionId,
	   SolutionCode+'/'+ISNULL(SolutionDesc,'') AS SolutionName
FROM dbo.Bas_Solution  WITH(NOLOCK) 
ORDER BY SolutionCode";

            try
            {
                source = DB.DBHelper.GetDataTable(sql, null , ExecuteType.Text);
                language.Clear();
                language.Add("SolutionName", "解决方案");
                cmbRepairErrorSolution.SetDataSource(source, language, true);
            }
            catch (Exception ex)
            {
                Component.MessageBox.MyMessageBox.ShowError(string.Format("加载解决方案错误：{0}", ex.Message));
                return;
            }


        }

        private void LoadWorkflow()
        {
            string sql;
            DataTable source = null;
            Dictionary<string, string> language = new Dictionary<string, string>();

            sql = @"SELECT WorkflowId,
	   WorkflowCode+'/'+ISNULL(WorkflowDesc,'') AS WorkflowName
FROM dbo.Bas_Workflow  WITH(NOLOCK) 
ORDER BY WorkflowCode";

            try
            {
                source = DB.DBHelper.GetDataTable(sql, null, ExecuteType.Text);
                language.Clear();
                language.Add("WorkflowName", "工作流");
                cmbWorkflow.SetDataSource(source, language, false);
                if (source.Rows.Count > 0)
                {
                    cmbWorkflow.SetSelectedIndex(0);
                    cmbWorkflow.SelectedIndexChanged += new RoutedEventHandler((sender, e) =>
                    {
                        if (ckbReStation.IsChecked.Value)
                        {
                            LoadStation();
                        }
                    });
                }
            }
            catch (Exception ex)
            {
                Component.MessageBox.MyMessageBox.ShowError(string.Format("加载工作流错误：{0}", ex.Message));
                return;
            }
        }


        //Dictionary<long, DataTable> WorkflowStations = new Dictionary<long, DataTable>();
        private void LoadStation()
        {
            if (!IsRepair)
                return;
            if (!ckbReStation.IsChecked.Value)
                return;
            long wId = 0;
            wId = WorkflowId.Value;
            //不允许修改工作流
            //if (!WorkflowId.HasValue || ckbReWorkflow.IsChecked.Value)
            //{
            //    if (cmbWorkflow.Value == null || cmbWorkflow.Value.ToString() == "")
            //    {
            //        return;
            //    }
            //    else
            //    {
            //        wId = long.Parse(cmbWorkflow.Value.ToString());
            //    }
            //}
            //else
            //{
            //    wId = WorkflowId.Value;
            //}



            string sql;
            Parameters parameters = null;
            DataTable source = null;
            Dictionary<string, string> language = new Dictionary<string, string>();
            language.Add("WorkflowStationName", "工作流节点");

            //if (WorkflowStations.ContainsKey(wId))
            //{
            //    source = WorkflowStations[wId];
            //}
            //else
            //{
//                sql = @"SELECT WorkflowStationId,
//	   dbo.Ftn_GetWorkflowStationName(WorkflowStationId) AS WorkflowStationName
//FROM dbo.Bas_WorkflowStation  WITH(NOLOCK) 
//WHERE WorkflowId=@WorkflowId
//ORDER BY WorkflowStationName";
                //parameters = new Parameters().Add("WorkflowId", wId);
                string CurrentProcess = tbRepairInputStation.Text.Split('/')[0];
                sql = @"Prd_GetFrontProcess";
                parameters = new Parameters().Add("CompareWorkflowId", wId)
                    .Add("CompareWorkflowStationId", "0")
                    .Add("CompareWorkflowStationCode", CurrentProcess)
                    .Add(new Parameter("Return_Message", DBNull.Value, SqlDbType.NVarChar, int.MaxValue, ParameterDirection.Output))
                    .Add(new Parameter("ReturnValue", DBNull.Value, SqlDbType.Int, ParameterDirection.ReturnValue));
                try
                {
                    source = DB.DBHelper.GetDataTable(sql, parameters, ExecuteType.StoredProcedure);

                    //WorkflowStations.Add(wId, source);
                }
                catch (Exception ex)
                {
                    Component.MessageBox.MyMessageBox.ShowError(string.Format("加载工作流节点错误：{0}", ex.Message));
                    return;
                }
            //}
            cmbStation.SetDataSource(source, language, false);
            if (source.Rows.Count > 0)
            {
                cmbStation.SetSelectedIndex(0);
            }
        }

        private void bdQuery_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e != null)
                e.Handled = true;
            if (string.IsNullOrEmpty(tbSN.Text.Trim()))
            {
                Component.MessageBox.MyMessageBox.ShowError("请先扫描批次条码");
                tbSN.SetFoucs();
                return;
            }

            if (!string.IsNullOrEmpty(LotSN) && tbSN.Text.Trim().ToUpper() == LotSN.ToUpper().Trim())
            {
                Component.MessageBox.MyMessageBox.ShowWarning(string.Format("已经在维修产品[{0}]", tbSN.Text.Trim()));
                tbSN.SetFoucs();
                return;
            }
            if (!Clear(false))
            {
                tbSN.SetFoucs();
                return;
            }
            string sql = @"SELECT Inp_RepairIn.LotId,
       Inp_RepairIn_Items.RepairIn_ItemsId,
	   Inp_RepairIn.RepairInId,
	   Inp_Lot.LotSNType,
	   Inp_Lot.LotSN,
	   Bas_ErrorCode.ErrorCode+'/'+ISNULL(Bas_ErrorCode.ErrorCodeDesc,'') AS ErrorCodeDesc,
	   Bas_ErrorCodeGroup.ErrorCodeGroupCode+'/'+ISNULL(Bas_ErrorCodeGroup.ErrorCodeGroupDesc,'') AS ErrorCodeGroupDesc,
	   Bas_ErrorType.ErrorTypeCode+'/'+ISNULL(Bas_ErrorType.ErrorTypeDesc,'') AS ErrorTypeDesc,
	   dbo.Bas_Order.OrderCode,
	   Bas_MO.MOCode,
	   Bas_Item.ItemCode,
	   Bas_Item.ItemSpecification,
       Bas_Workflow.WorkflowCode,
	   dbo.Ftn_GetWorkflowStationName(Bas_WorkflowStation.WorkflowStationId) AS WorkflowStationName,
	   Bas_Line.LineCode+'/'+Bas_Line.LineDesc AS LineDesc,
	   Bas_Res.ResCode+'/'+Bas_Res.ResDesc AS ResDesc,
	   Bas_Shift.ShiftCode+'/'+Bas_Shift.ShiftDesc AS ShiftDesc,
	   Set_User.SysUserCode+'/'+Set_User.SysUserName AS UserName,
	   Inp_RepairIn.CreateDateTime,Inp_RepairIn_Items.Status as ErrorStatus,
	   Inp_Lot.IsLock,
	   Inp_Lot.IsError,
	   dbo.Inp_Lot.WorkflowId,
	   Inp_Lot.PreviousWorkflowId,
	   Inp_Lot.IsPack
FROM dbo.Inp_RepairIn  WITH(NOLOCK) 
LEFT JOIN dbo.Inp_RepairIn_Items  WITH(NOLOCK) ON dbo.Inp_RepairIn_Items.RepairInId = dbo.Inp_RepairIn.RepairInId
LEFT JOIN dbo.Bas_ErrorCode  WITH(NOLOCK) ON Inp_RepairIn_Items.ErrorCodeId=Bas_ErrorCode.ErrorCodeId
LEFT JOIN dbo.Bas_ErrorCodeGroup  WITH(NOLOCK) ON dbo.Bas_ErrorCodeGroup.ErrorCodeGroupId = dbo.Bas_ErrorCode.ErrorCodeGroupId
LEFT JOIN dbo.Bas_ErrorType  WITH(NOLOCK) ON Bas_ErrorCode.ErrorTypeId=Bas_ErrorType.ErrorTypeId
LEFT JOIN dbo.Inp_Lot  WITH(NOLOCK) ON dbo.Inp_Lot.LotId = dbo.Inp_RepairIn.LotId
LEFT JOIN dbo.Bas_MO  WITH(NOLOCK) ON dbo.Bas_MO.MOId = dbo.Inp_RepairIn.MOId
LEFT JOIN dbo.Bas_OrderDetail  WITH(NOLOCK) ON dbo.Bas_OrderDetail.OrderDetailId = dbo.Bas_MO.OrderDetailId
LEFT JOIN dbo.Bas_Order  WITH(NOLOCK) ON dbo.Bas_Order.OrderId = dbo.Bas_OrderDetail.OrderId
LEFT JOIN dbo.Bas_Item  WITH(NOLOCK) ON dbo.Bas_Item.ItemId = dbo.Inp_RepairIn.ItemId
LEFT JOIN dbo.Bas_Workflow  WITH(NOLOCK) ON dbo.Bas_Workflow.WorkflowId = dbo.Inp_RepairIn.WorkflowId
LEFT JOIN dbo.Bas_WorkflowStation  WITH(NOLOCK) ON Inp_RepairIn.WorkflowStationId=Bas_WorkflowStation.WorkflowStationId
LEFT JOIN dbo.Bas_OP  WITH(NOLOCK) ON Inp_RepairIn.OPId=Bas_OP.OPId
LEFT JOIN dbo.Bas_Line  WITH(NOLOCK) ON dbo.Bas_Line.LineId = dbo.Inp_RepairIn.LineId
LEFT JOIN dbo.Bas_Res  WITH(NOLOCK) ON dbo.Bas_Res.ResId = dbo.Inp_RepairIn.ResId
LEFT JOIN dbo.Bas_Shift  WITH(NOLOCK) ON Inp_RepairIn.ShiftId=Bas_Shift.ShiftId
LEFT JOIN dbo.Set_User  WITH(NOLOCK) ON dbo.Set_User.SysUserId = dbo.Inp_RepairIn.CreateUserId
WHERE Inp_Lot.LotId=dbo.Ftn_GetLotId(@LotSN,NULL)  AND Inp_RepairIn.Status NOT IN ('Complete','Scrap','ErrorInStore')";
            Parameters parameters = new Parameters().Add("LotSN", tbSN.Text.Trim());

            try
            {
                DataTable dt = DB.DBHelper.GetDataTable(sql, parameters, ExecuteType.Text);
                DataColumn col = new DataColumn("Delete", typeof(Byte[]));
                col.DefaultValue = WinAPI.File.ImageHelper.ConvertToByte(Properties.Resources.error35_35);
                dt.Columns.Add(col);

                DataColumn col1 = new DataColumn("Command", typeof(Byte[]));
                col1.DefaultValue = WinAPI.File.ImageHelper.ConvertToByte(Properties.Resources.hand1_35_35);
                dt.Columns.Add(col1);

                bool IsError = false;
                long? PreviousWorkflowId = null;
                long? errorCodeId = null;
                if (dt.Rows.Count > 0)
                {
                    RepairInSource = dt.Clone();
                    dt.Select("ErrorStatus='WaitRepair'").ToList().ForEach(i =>
                    {
                        RepairInSource.ImportRow(i);
                    });
                    if (bool.Parse(dt.Rows[0]["IsLock"].ToString()))
                    {
                        Component.MessageBox.MyMessageBox.ShowWarning(string.Format("批次条码[{0}]已被锁定，不能维修", tbSN.Text.Trim()));
                        Clear(true);
                        tbSN.SetFoucs();
                        return;
                    }
                    IsScrap = false;
                    IsComplete = false;
                    IsComplete = false;
                    IsError = true;
                    LotId = long.Parse(dt.Rows[0]["LotId"].ToString());
                    WorkflowId = dt.Rows[0]["WorkflowId"] == null || dt.Rows[0]["WorkflowId"] == DBNull.Value ? null : (long?)long.Parse(dt.Rows[0]["WorkflowId"].ToString());
                    PreviousWorkflowId = dt.Rows[0]["PreviousWorkflowId"] == null || dt.Rows[0]["PreviousWorkflowId"] == DBNull.Value ? null : (long?)long.Parse(dt.Rows[0]["PreviousWorkflowId"].ToString());
                    LotSN = dt.Rows[0]["LotSN"].ToString();
                    LotSNType = dt.Rows[0]["LotSNType"].ToString();
                    OrderCode = dt.Rows[0]["OrderCode"].ToString();
                    MoCode = dt.Rows[0]["MOCode"].ToString();
                    ItemCode = dt.Rows[0]["ItemCode"].ToString();
                    ItemDesc = dt.Rows[0]["ItemSpecification"].ToString();
                    WorkflowStationCode = dt.Rows[0]["WorkflowStationName"].ToString();
                    LineName = dt.Rows[0]["LineDesc"].ToString();
                    RepairInId = long.Parse(dt.Rows[0]["RepairInId"].ToString());

                }
                else
                {
                    RepairInSource = dt;
                    sql = @"SELECT Inp_Lot.LotSNType,
	   Inp_Lot.LotSN,
	   dbo.Bas_Order.OrderCode,
	   Bas_MO.MOCode,
	   Bas_Item.ItemCode,
	   Bas_Item.ItemSpecification,
       Bas_Workflow.WorkflowCode,
	   dbo.Ftn_GetWorkflowStationName(Bas_WorkflowStation.WorkflowStationId) AS WorkflowStationName,
	   Bas_Line.LineCode+'/'+Bas_Line.LineDesc AS LineDesc,
	   Bas_Res.ResCode+'/'+Bas_Res.ResDesc AS ResDesc,
	   Bas_Shift.ShiftCode+'/'+Bas_Shift.ShiftDesc AS ShiftDesc,
	   Set_User.SysUserCode+'/'+Set_User.SysUserName AS UserName,
	   Inp_Lot.IsLock,
	   Inp_Lot.IsError,
	   Inp_Lot.LotId,
	   dbo.Inp_Lot.WorkflowId,
	   Inp_Lot.PreviousWorkflowId,
	   Inp_Lot.IsPack,
	   Inp_Lot.Status,
	   Inp_Lot.ErrorCodeIds
FROM dbo.Inp_Lot  WITH(NOLOCK)
LEFT JOIN dbo.Bas_MO  WITH(NOLOCK) ON dbo.Bas_MO.MOId = dbo.Inp_Lot.MOId
LEFT JOIN dbo.Bas_OrderDetail  WITH(NOLOCK) ON dbo.Bas_OrderDetail.OrderDetailId = dbo.Bas_MO.OrderDetailId
LEFT JOIN dbo.Bas_Order  WITH(NOLOCK) ON dbo.Bas_Order.OrderId = dbo.Bas_OrderDetail.OrderId
LEFT JOIN dbo.Bas_Item  WITH(NOLOCK) ON dbo.Bas_Item.ItemId = dbo.Inp_Lot.ItemId
LEFT JOIN dbo.Bas_Workflow  WITH(NOLOCK) ON dbo.Bas_Workflow.WorkflowId = dbo.Inp_Lot.WorkflowId
LEFT JOIN dbo.Bas_WorkflowStation  WITH(NOLOCK) ON Inp_Lot.WorkflowStationId=Bas_WorkflowStation.WorkflowStationId
LEFT JOIN dbo.Bas_OP  WITH(NOLOCK) ON Inp_Lot.OPId=Bas_OP.OPId
LEFT JOIN dbo.Bas_Line  WITH(NOLOCK) ON dbo.Bas_Line.LineId = dbo.Inp_Lot.LineId
LEFT JOIN dbo.Bas_Res  WITH(NOLOCK) ON dbo.Bas_Res.ResId = dbo.Inp_Lot.ResId
LEFT JOIN dbo.Bas_Shift  WITH(NOLOCK) ON Inp_Lot.ShiftId=Bas_Shift.ShiftId
LEFT JOIN dbo.Set_User  WITH(NOLOCK) ON dbo.Set_User.SysUserId = dbo.Inp_Lot.CreateUserId
WHERE Inp_Lot.LotId=dbo.Ftn_GetLotId(@LotSN,NULL) ";
                    DataTable source = DB.DBHelper.GetDataTable(sql, parameters, null);
                    if (source.Rows.Count < 1)
                    {
                        Clear(true);
                        tbSN.SetFoucs();
                        AddMessage(string.Format("批次条码[{0}]错误", tbSN.Text.Trim()), true);
                        return;
                    }

                    bool IsPack = bool.Parse(source.Rows[0]["IsPack"].ToString());
                    IsError = bool.Parse(source.Rows[0]["IsError"].ToString());
                    IsScrap = source.Rows[0]["Status"].ToString().ToUpper() == "SCRAP" ? true : false;
                    IsComplete = source.Rows[0]["Status"].ToString().ToUpper() == "COMPLETE" ? true : false;
                    IsErrorInStore = source.Rows[0]["Status"].ToString().ToUpper() == "ERRORINSTORE" ? true : false;
                    LotId = long.Parse(source.Rows[0]["LotId"].ToString());
                    WorkflowId = source.Rows[0]["WorkflowId"] == null || source.Rows[0]["WorkflowId"] == DBNull.Value ? null : (long?)long.Parse(source.Rows[0]["WorkflowId"].ToString());
                    PreviousWorkflowId = source.Rows[0]["PreviousWorkflowId"] == null || source.Rows[0]["PreviousWorkflowId"] == DBNull.Value ? null : (long?)long.Parse(source.Rows[0]["PreviousWorkflowId"].ToString());
                    LotSN = source.Rows[0]["LotSN"].ToString();
                    LotSNType = source.Rows[0]["LotSNType"].ToString();
                    OrderCode = source.Rows[0]["OrderCode"].ToString();
                    MoCode = source.Rows[0]["MOCode"].ToString();
                    ItemCode = source.Rows[0]["ItemCode"].ToString();
                    ItemDesc = source.Rows[0]["ItemSpecification"].ToString();
                    WorkflowStationCode = source.Rows[0]["WorkflowStationName"].ToString();
                    string ErrorCodeIds = source.Rows[0]["ErrorCodeIds"].ToString();
                    LineName = source.Rows[0]["LineDesc"].ToString();
                    RepairInId = null;



                    if (!string.IsNullOrEmpty(ErrorCodeIds))
                    {
                        string[] strs = ErrorCodeIds.Split(new string[] { ";" }, StringSplitOptions.RemoveEmptyEntries);
                        if(strs.Length>0)
                        {
                            string str = strs[strs.Length - 1];
                            long eId = 0;
                            if(long.TryParse(str,out eId))
                            {
                                errorCodeId = eId;
                            }
                        }
                    }


                    if (bool.Parse(source.Rows[0]["IsLock"].ToString()))
                    {
                        Component.MessageBox.MyMessageBox.ShowWarning(string.Format("批次条码[{0}]已被锁定，不能维修", tbSN.Text.Trim()));
                        Clear(true);
                        tbSN.SetFoucs();
                        return;
                    }

                    if (IsPack)
                    {
                        Clear(true);
                        tbSN.SetFoucs();
                        AddMessage(string.Format("批次条码[{0}]已层级包装，请先拆包装再维修", tbSN.Text.Trim()), true);
                        return;
                    }

                    if (IsScrap)
                    {
                        if (Component.MessageBox.MyMessageBox.Show(string.Format("产品[{0}]已报废，确定维修吗？", LotSN), "提示",
                            MessageBoxButton.OKCancel, MessageBoxImage.Warning) == MessageBoxResult.Cancel)
                        {
                            Clear(true);
                            tbSN.SetFoucs();
                            return;
                        }
                    }
                    else if (IsComplete)
                    {
                        if (Component.MessageBox.MyMessageBox.Show(string.Format("产品[{0}]已完工，确定维修吗？", LotSN), "提示",
                            MessageBoxButton.OKCancel, MessageBoxImage.Warning) == MessageBoxResult.Cancel)
                        {
                            Clear(true);
                            tbSN.SetFoucs();
                            return;
                        }
                    }
                    else if (IsErrorInStore)
                    {
                        if (Component.MessageBox.MyMessageBox.Show(string.Format("产品[{0}]已不良入库，确定维修吗？", LotSN), "提示",
                            MessageBoxButton.OKCancel, MessageBoxImage.Warning) == MessageBoxResult.Cancel)
                        {
                            Clear(true);
                            tbSN.SetFoucs();
                            return;
                        }
                    }
                    else if (!IsError)
                    {
                        if (Component.MessageBox.MyMessageBox.Show(string.Format("产品[{0}]并非不良品，确定维修吗？", LotSN), "提示",
                            MessageBoxButton.OKCancel, MessageBoxImage.Warning) == MessageBoxResult.Cancel)
                        {
                            Clear(true);
                            tbSN.SetFoucs();
                            return;
                        }
                    }
                }

                if (IsScrap)
                {
                    AddMessage(string.Format("开始维修报废产品[{0}]", LotSN), false);
                }
                else if (IsComplete)
                {
                    AddMessage(string.Format("开始维修完工产品[{0}]", LotSN), false);
                }
                else if (IsErrorInStore)
                {
                    AddMessage(string.Format("开始维修不良入库产品[{0}]", LotSN), false);
                }
                else
                {
                    AddMessage(string.Format("开始维修产品[{0}]", LotSN), false);
                }

                tbRepairSN.Text = LotSN;
                tbOrder.Text = OrderCode;
                tbRepairMO.Text = MoCode;
                tbRepairItem.Text = ItemCode + "/" + ItemDesc;
                tbRepairInputStation.Text = WorkflowStationCode;
                tbRepairInputLine.Text = LineName;

                gridRepairIn.ItemsSource = RepairInSource;
                gridViewRepairIn.BestFitColumns();
                IsRepair = true;

                if (IsComplete || !WorkflowId.HasValue)
                {
                    ckbReWorkflow.IsChecked = true;
                    ckbReStation.IsChecked = true;

                    if (WorkflowId.HasValue)
                    {
                        cmbWorkflow.Value = WorkflowId.Value;
                    }
                    else if (PreviousWorkflowId.HasValue)
                    {
                        cmbWorkflow.Value = PreviousWorkflowId.Value;
                    }
                }

                if (!IsError || !RepairInId.HasValue)
                {
                    if (errorCodeId.HasValue)
                    {
                        if (!CreateErrorCode(errorCodeId.Value))
                        {
                            Clear(true);
                            tbSN.SetFoucs();
                        }
                    }
                    else
                    {
                        if (!CreateErrorCode())
                        {
                            Clear(true);
                            tbSN.SetFoucs();
                        }
                    }
                }
                else if (RepairInSource != null && RepairInSource.Rows.Count > 0)
                {
                    gridViewRepairIn.FocusedRowHandle = gridRepairIn.GetRowHandleByListIndex(RepairInSource.Rows.Count - 1);
                    gridRepairIn.CurrentColumn = gridRepairIn.Columns["Command"];
                    gridViewRepairIn_MouseDown(gridViewRepairIn, null);
                    SetRepairFocus(cmbRepairErrorReason, false);
                }

                History();
            }
            catch (Exception ex)
            {
                Component.MessageBox.MyMessageBox.ShowError(ex.Message);
                tbSN.SetFoucs();
                Clear(true);
                return;
            }
        }



        private bool CreateErrorCode()
        {
            if (!IsRepair || RepairInSource == null)
                return false;
            AddErrorCode instance = new AddErrorCode(LotId, LotSN, MoCode, ItemCode + "/" + ItemDesc, WorkflowStationCode, OrderCode, this);
            instance.Owner = Component.App.Portal;
            bool? result = instance.ShowDialog();
            //if (!result.HasValue || !result.Value)
            //{
            //    return false;
            //}
            //return true;
            if (instance.AddCount > 0)
            {
                DataRowView row = gridRepairIn.CurrentItem as DataRowView;

                gridRepairIn.CurrentColumn = gridRepairIn.Columns["Command"];
                if (row == null)
                {
                    gridViewRepairIn.FocusedRowHandle = gridRepairIn.GetRowHandleByListIndex(RepairInSource.Rows.Count - 1);
                    gridViewRepairIn_MouseDown(gridViewRepairIn, null);
                }
                else
                {
                    gridViewRepairIn_MouseDown(gridViewRepairIn, null);
                }
                return true;
            }
            else
            {
                return false;
            }

        }

        public bool CreateErrorCode(long ErrorId)
        {
            string sql = @"DECLARE @ShiftId BIGINT
DECLARE @ShiftTimeSpanId BIGINT
EXEC dbo.Prd_GetShiftIdAndShiftTimeSpanId @ShiftTypeId = @ShiftTypeId, -- bigint
    @ShiftId = @ShiftId OUTPUT, -- bigint
    @ShiftTimeSpanId = @ShiftTimeSpanId OUTPUT -- bigint

SELECT @ShiftName=ShiftCode+'/'+ISNULL(ShiftDesc,'') FROM dbo.Bas_Shift WHERE ShiftId=@ShiftId 

EXEC dbo.Prd_Inp_Lot_Error 
	@LotId = @LotId , -- bigint
    @ErrorIds = @ErrorIds, -- nvarchar(max)
    @LineId = NULL, -- bigint
    @ResId = @ResId, -- bigint
    @ShiftId = @ShiftId, -- bigint
    @ShiftTimeSpanId = @ShiftTimeSpanId, -- bigint
    @UserId = @UserId, -- bigint
    @PluginId=@PluginId,
    @Comment=@Comment,
    @RepairIn_ItemsId=@RepairIn_ItemsId OUTPUT ,
    @RepairInId = @RepairInId OUTPUT-- bigint";
            Parameters parameters = new Parameters().Add("ShiftTypeId", Framework.App.Resource.ShiftTypeId)
                .Add("LotId", LotId).Add("ErrorIds", ErrorId).Add("ResId", Framework.App.Resource.ResourceId)
                .Add("UserId", Framework.App.User.UserId)
                .Add("RepairInId", RepairInId.HasValue ? (object)RepairInId.Value : null, SqlDbType.BigInt, 50, ParameterDirection.InputOutput)
                .Add("ShiftName", null, SqlDbType.NVarChar, 200, ParameterDirection.Output)
                .Add("PluginId", PluginId)
                .Add("Comment", string.Format("维修员[{0}/{1}]手工添加不良", Framework.App.User.UserCode, Framework.App.User.UserName))
                .Add("RepairIn_ItemsId", null, SqlDbType.BigInt, 50, ParameterDirection.Output);
            try
            {
                parameters = DB.DBHelper.ExecuteParameters(sql, parameters, ExecuteType.Text);
                RepairInId = long.Parse(parameters["RepairInId"].ToString());

                sql = @"SELECT Bas_ErrorCode.ErrorCode+'/'+ISNULL(Bas_ErrorCode.ErrorCodeDesc,'') AS ErrorCodeDesc,
	   Bas_ErrorCodeGroup.ErrorCodeGroupCode+'/'+ISNULL(Bas_ErrorCodeGroup.ErrorCodeGroupDesc,'') AS ErrorCodeGroupDesc,
	   Bas_ErrorType.ErrorTypeCode+'/'+ISNULL(Bas_ErrorType.ErrorTypeDesc,'') AS ErrorTypeDesc,
	   GETDATE() AS [Date]
FROM dbo.Bas_ErrorCode  WITH(NOLOCK) 
LEFT JOIN dbo.Bas_ErrorCodeGroup  WITH(NOLOCK) ON dbo.Bas_ErrorCodeGroup.ErrorCodeGroupId = dbo.Bas_ErrorCode.ErrorCodeGroupId
LEFT JOIN dbo.Bas_ErrorType  WITH(NOLOCK) ON dbo.Bas_ErrorType.ErrorTypeId = dbo.Bas_ErrorCode.ErrorTypeId
WHERE Bas_ErrorCode.ErrorCodeId=@ErrorId";
                Parameters pm = new Parameters().Add("ErrorId", ErrorId);
                DataTable source = DB.DBHelper.GetDataTable(sql, pm,ExecuteType.Text);

                DataRow row = RepairInSource.NewRow();
                row["RepairIn_ItemsId"] = parameters["RepairIn_ItemsId"];
                row["LotId"] = LotId;
                row["RepairInId"] = RepairInId;
                row["LotSNType"] = LotSNType;
                row["LotSN"] = LotSN;
                row["ErrorCodeDesc"] = source.Rows[0]["ErrorCodeDesc"];
                row["ErrorCodeGroupDesc"] = source.Rows[0]["ErrorCodeGroupDesc"];
                row["ErrorTypeDesc"] = source.Rows[0]["ErrorTypeDesc"];
                row["OrderCode"] = OrderCode;
                row["MOCode"] = MoCode;
                row["ItemCode"] = ItemCode;
                row["ItemSpecification"] = ItemDesc;
                row["WorkflowStationName"] = WorkflowStationCode;
                row["LineDesc"] = LineName;
                row["ResDesc"] = string.Format("{0}/{1}", Framework.App.Resource.ResourceCode, Framework.App.Resource.ResourceDesc);
                row["ShiftDesc"] = parameters["ShiftName"].ToString();
                row["UserName"] = string.Format("{0}/{1}", Framework.App.User.UserCode, Framework.App.User.UserName);
                row["IsLock"] = false;
                row["CreateDateTime"] = source.Rows[0]["Date"];
                row["WorkflowId"] = WorkflowId.HasValue ? (object)WorkflowId.Value : DBNull.Value;
                RepairInSource.Rows.Add(row);
                gridViewRepairIn.BestFitColumns();
                //gridViewRepairIn.FocusedRowHandle = gridRepairIn.GetRowHandleByListIndex(RepairInSource.Rows.Count - 1);
                // gridViewRepairIn_MouseDown(gridViewRepairIn, null);
                return true;
            }
            catch (Exception ex)
            {
                Component.MessageBox.MyMessageBox.ShowError(ex.Message);
            }
            return false;
        }

        private void btnAddError_Click(object sender, RoutedEventArgs e)
        {
            if (!IsRepair)
                return;

            CreateErrorCode();
        }

        private bool IsRepairErrorCode = false;
        private long? RepairIn_ItemsId = null;

        private void gridViewRepairIn_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (!IsRepair)
            {
                return;
            }
            if (gridRepairIn.CurrentColumn == colDeleteErrorCode)
            {
                DataRowView row = gridRepairIn.CurrentItem as DataRowView;
                if (row != null)
                {
                    if (Component.MessageBox.MyMessageBox.Show(string.Format("确定删除不良代码[{0}]？", row["ErrorCodeDesc"]), "提示",
                                 MessageBoxButton.OKCancel, MessageBoxImage.Warning) == System.Windows.MessageBoxResult.Cancel)
                    {
                        return;
                    }


                    string sql = "UPDATE Inp_RepairIn_Items SET Status='Delete',DeleteUserId=@UserId,DeleteDateTime=GETDATE() WHERE RepairIn_ItemsId=@ItemId";
                    Parameters parameters = new Parameters().Add("UserId", Framework.App.User.UserId).Add("ItemId", row["RepairIn_ItemsId"]);
                    try
                    {
                        DB.DBHelper.Execute(sql, parameters, ExecuteType.Text);

                        ((gridRepairIn.ItemsSource) as DataTable).Rows.Remove(row.Row);
                        ClearRepairInfo();
                        History();

                        if (((gridRepairIn.ItemsSource) as DataTable).Rows.Count > 0)
                        {
                            gridRepairIn.CurrentColumn = gridRepairIn.Columns["Command"];
                            gridViewRepairIn_MouseDown(gridViewRepairIn, null);
                        }
                        else
                        {
                            btnRepairComplete_Click(btnRepairComplete, null);
                        }
                    }
                    catch (Exception ex)
                    {
                        Component.MessageBox.MyMessageBox.ShowError(ex.Message);
                    }

                }
                return;
            }
            else //if (gridRepairIn.CurrentColumn == colCommand)
            {
                DataRowView row = gridRepairIn.CurrentItem as DataRowView;
                if (row != null)
                {
                    if (IsRepairErrorCode)
                    {
                        if (RepairIn_ItemsId.Value != long.Parse(row["RepairIn_ItemsId"].ToString()))
                        {
                            if (Component.MessageBox.MyMessageBox.Show(string.Format("正在维修不良[{0}],确定取消保存吗？", tbRepairError.Text), "提示",
                                  MessageBoxButton.OKCancel, MessageBoxImage.Warning) == System.Windows.MessageBoxResult.Cancel)
                            {
                                return;
                            }
                        }
                    }

                    ClearRepairInfo();

                    RepairIn_ItemsId = long.Parse(row["RepairIn_ItemsId"].ToString());
                    tbRepairSN.Text = row["LotSN"].ToString();
                    tbOrder.Text = row["OrderCode"].ToString();
                    tbRepairMO.Text = row["MOCode"].ToString();
                    tbRepairItem.Text = row["ItemCode"].ToString() + "/" + row["ItemSpecification"].ToString();
                    tbRepairError.Text = row["ErrorCodeDesc"].ToString();
                    tbRepairErrorType.Text = row["ErrorTypeDesc"].ToString();
                    tbRepairInputStation.Text = row["WorkflowStationName"].ToString();
                    tbRepairInputLine.Text = row["LineDesc"].ToString();
                    tbRepairInputUser.Text = row["UserName"].ToString();

                    btnSave.Visibility = Visibility.Visible;
                    btnCancel.Visibility = Visibility.Visible;
                    btnRepairComplete.Visibility = Visibility.Collapsed;
                    btnAddError.Visibility = Visibility.Collapsed;
                    epdRepair.Visibility = Visibility.Visible;
                    gridLock.Visibility = Visibility.Collapsed;
                    IsRepairErrorCode = true;


                    SetRepairFocus(cmbRepairErrorReason, false);
                }
            }
        }

        private void ClearRepairInfo()
        {
            cmbRepairErrorReason.Value = null;
            tbRepairErrorLocation.Text = "";
            tbRepairErrorPoints.Text = "";
            cmbRepairErrorDuty.Value = null;
            cmbRepairErrorSolution.Value = null;
            tbRepairContent.Text = "";
            tbRepairErrorNote.Text = "";
            tbMaterialSN.Text = "";
            tbQty.Value = null;
            tbReplaceReason.Text = "";
            gridReplace.ItemsSource = null;

            btnSave.Visibility = Visibility.Collapsed;
            btnCancel.Visibility = Visibility.Collapsed;
            btnRepairComplete.Visibility = Visibility.Visible;
            btnAddError.Visibility = Visibility.Visible;
            epdRepair.Visibility = Visibility.Collapsed;
            gridLock.Visibility = Visibility.Visible;
            IsRepairErrorCode = false;
        }

        private void btnAddReplace_Click(object sender, RoutedEventArgs e)
        {
            string sn = tbMaterialSN.Text.Trim();
            if (sn == "")
            {
                Component.MessageBox.MyMessageBox.ShowError("请输入物料批次条码！");
                tbMaterialSN.SetFoucs();
                return;
            }
            if (tbQty.Value == null)
            {
                Component.MessageBox.MyMessageBox.ShowError("请输入数量！");
                tbQty.SetFoucs();
                return;
            }

            float qty = float.Parse(tbQty.Value.ToString());

            if (qty <= 0)
            {
                Component.MessageBox.MyMessageBox.ShowError("数量必须大于零！");
                tbQty.SetFoucs();
                return;
            }

            if (gridReplace.ItemsSource == null)
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("SN", typeof(System.String));
                dt.Columns.Add("Qty", typeof(System.Decimal));
                dt.Columns.Add("Reason", typeof(System.String));
                DataColumn col = new DataColumn("Command", typeof(System.Byte[]));
                col.DefaultValue = WinAPI.File.ImageHelper.ConvertToByte(Properties.Resources.error35_35);
                dt.Columns.Add(col);
                gridReplace.ItemsSource = dt;
            }

            DataTable source = gridReplace.ItemsSource as DataTable;
            DataRow row = source.NewRow();
            row["SN"] = sn;
            row["Qty"] = qty;
            row["Reason"] = tbReplaceReason.Text.Trim();
            source.Rows.Add(row);
            gridViewReplace.FocusedRowHandle = gridReplace.GetRowHandleByListIndex(source.Rows.Count - 1);
            gridViewReplace.BestFitColumns();

            tbMaterialSN.Text = "";
            tbQty.Value = null;
            tbReplaceReason.Text = "";
            tbMaterialSN.SetFoucs();
        }

        private void gridViewReplace_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (!IsRepair || gridReplace.ItemsSource == null)
            {
                return;
            }
            if (gridReplace.CurrentColumn == colSNCommand)
            {
                DataRowView row = gridReplace.GetFocusedRow() as DataRowView;
                if (row != null)
                {
                    if (Component.MessageBox.MyMessageBox.Show(string.Format("确定删除物料批次[{0}]吗？", row["SN"]), "提示",
                                 MessageBoxButton.OKCancel, MessageBoxImage.Warning) == System.Windows.MessageBoxResult.Cancel)
                    {
                        return;
                    }
                    ((gridReplace.ItemsSource) as DataTable).Rows.Remove(row.Row);
                }
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            if (!IsRepair || !IsRepairErrorCode)
            {
                return;
            }

            if (Component.MessageBox.MyMessageBox.Show(string.Format("确定取消保存吗？", tbRepairError.Text), "提示",
                                 MessageBoxButton.OKCancel, MessageBoxImage.Warning) == System.Windows.MessageBoxResult.Cancel)
            {
                return;
            }

            ClearRepairInfo();
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            if (!IsRepair || !IsRepairErrorCode)
            {
                return;
            }

            if (!RepairIn_ItemsId.HasValue)
            {
                Component.MessageBox.MyMessageBox.ShowError("系统错误，未获取到不良明细");
                return;
            }



            if (!RepairInId.HasValue)
            {
                Component.MessageBox.MyMessageBox.ShowError("系统错误，未获取到不良信息");
                return;
            }

            if (Component.MessageBox.MyMessageBox.Show(string.Format("确定保存吗？", tbRepairError.Text), "提示",
                                 MessageBoxButton.OKCancel, MessageBoxImage.Warning) == System.Windows.MessageBoxResult.Cancel)
            {
                return;
            }

            string sql = null;
            #region
            sql = @"--DECLARE @RepairInId BIGINT
--DECLARE @RepairIn_ItemsId BIGINT

--DECLARE @xml XML
--set @xml='
--<document>
--	<MaterialSNs>
--		<item rowIndex="" MaterialSN="" Qty="" Reason=""></item>
--		<item rowIndex="" MaterialSN="" Qty="" Reason=""></item>
--		<item rowIndex="" MaterialSN="" Qty="" Reason=""></item>
--	</<MaterialSNs>>
--</document>'

DECLARE @t TABLE(
	rowIndex INT,
	MaterialSN NVARCHAR(50),
	Qty DECIMAL(18,6),
	Reason NVARCHAR(max)
)

INSERT INTO @t
SELECT item.value('./@rowIndex','int') as rowIndex,
	   item.value('./@MaterialSN','nvarchar(50)') as MaterialSN,
	   CASE WHEN ISNULL(item.value('./@Qty','nvarchar(50)'),'')='' THEN NULL ELSE item.value('./@Qty','DECIMAL(18,6)') END as Qty,
	   item.value('./@Reason','nvarchar(max)') as Reason
FROM @xml.nodes('document/MaterialSNs/item') UT(item) 


DECLARE @ShiftId BIGINT
DECLARE @ShiftTimeSpanId BIGINT

EXEC dbo.Prd_GetShiftIdAndShiftTimeSpanId @ShiftTypeId = @ShiftTypeId, -- bigint
    @ShiftId = @ShiftId OUTPUT, -- bigint
    @ShiftTimeSpanId = @ShiftTimeSpanId OUTPUT


UPDATE dbo.Inp_RepairIn SET Status='Repairing' WHERE RepairInId=@RepairInId
UPDATE dbo.Inp_RepairIn_Items SET Status='RepairComplete' WHERE RepairIn_ItemsId=@RepairIn_ItemsId

DECLARE @RepairInfoId BIGINT
EXEC dbo.Prd_ApplyTableId @TableName = N'Inp_RepairInfo', -- nvarchar(50)
    @Id = @RepairInfoId OUTPUT -- bigint


INSERT INTO dbo.Inp_RepairInfo
        ( RepairInfoId ,
          RepairInId ,
          RepairIn_ItemsId ,
          DataChainId ,
          LotId ,
          MOId ,
          ItemId ,
          OPId ,
          LineId ,
          ResId ,
          ShiftId ,
          ShiftTimeSpanId ,
          ErrorCodeId ,
          ErrorReasonId ,
          DutyId ,
          SolutionId ,
          ErrorLocation ,
          ErrorPoint ,
		  RepairContent,
          Note ,
          CreateUserId ,
          CreateDateTime
        )SELECT @RepairInfoId,
			    Inp_RepairIn_Items.RepairInId,
				Inp_RepairIn_Items.RepairIn_ItemsId,
				Inp_RepairIn.DataChainId,
				Inp_RepairIn.LotId,
				Inp_RepairIn.MOId,
				Inp_RepairIn.ItemId,
				@OPId,
				@LineId,
				@ResId,
				@ShiftId,
				@ShiftTimeSpanId,
				Inp_RepairIn_Items.ErrorCodeId,
				@ErrorReasonId,
				@DutyId,
				@SolutionId,
				@ErrorLocation,
				@ErrorPoint,
				@RepairContent,
				@Note,
				@UserId,
				GETDATE()
FROM Inp_RepairIn_Items  WITH(NOLOCK) 
LEFT JOIN Inp_RepairIn  WITH(NOLOCK) ON dbo.Inp_RepairIn.RepairInId = dbo.Inp_RepairIn_Items.RepairInId
WHERE Inp_RepairIn_Items.RepairIn_ItemsId= @RepairIn_ItemsId

DECLARE @count INT
SELECT @count=COUNT(*) FROM @t
IF @count>0
 BEGIN
	DECLARE @t1 TABLE(
		Id BIGINT,
		rowIndex INT
	)

	INSERT INTO @t1
	EXEC dbo.Prd_ApplySetTableId @TableName = N'Inp_RepairInfo_Material', -- nvarchar(50)
	    @Count = @count -- int

	INSERT INTO dbo.Inp_RepairInfo_Material
	        ( RepairInfo_MaterialId ,
	          RepairInfoId ,
	          MaterialId ,
	          MaterialSN ,
	          Quantity ,
	          Reason ,
	          CreateUserId ,
	          CreateDateTime
	        )SELECT a.Id,
				    @RepairInfoId,
					-1 AS MaterialId,
					b.MaterialSN,
					b.Qty,
					b.Reason,
					@UserId,
					GETDATE()
	FROM @t1 a
	LEFT JOIN @t b ON a.rowIndex=b.rowIndex
 END
";
            #endregion

            Parameters parameters = new Parameters()
                    .Add("UserId", Framework.App.User.UserId)
                    .Add("OPId", Framework.App.Resource.StationId)
                    .Add("LineId", Framework.App.Resource.LineId)
                    .Add("ResId", Framework.App.Resource.ResourceId)
                    .Add("ShiftTypeId", Framework.App.Resource.ShiftTypeId)
                    .Add("RepairInId", RepairInId)
                    .Add("RepairIn_ItemsId", RepairIn_ItemsId)
                    .Add("ErrorReasonId", cmbRepairErrorReason.Value)
                    .Add("DutyId", cmbRepairErrorDuty.Value)
                    .Add("SolutionId", cmbRepairErrorSolution.Value)
                    .Add("ErrorLocation", tbRepairErrorLocation.Text.Trim())
                    .Add("ErrorPoint", tbRepairErrorPoints.Text.Trim())
                    .Add("RepairContent", tbRepairContent.Text.Trim())
                    .Add("Note", tbRepairErrorNote.Text.Trim());

            string xml = null;
            if (gridReplace.ItemsSource != null)
            {
                DataTable source = gridReplace.ItemsSource as DataTable;
                Dictionary<string, List<Dictionary<string, object>>> l = new Dictionary<string, List<Dictionary<string, object>>>();
                int rowIndex = 1;
                List<Dictionary<string, object>> la = new List<Dictionary<string, object>>();
                foreach (DataRow row in source.Rows)
                {
                    Dictionary<string, object> st = new Dictionary<string, object>();
                    st.Add("rowIndex", rowIndex);
                    st.Add("MaterialSN", row["SN"]);
                    st.Add("Qty", row["Qty"]);
                    st.Add("Reason", row["Reason"]);
                    la.Add(st);
                    rowIndex++;
                }
                l.Add("MaterialSNs", la);

                xml = WinAPI.File.XMLHelper.CreateXML(null, l);
            }
            parameters = parameters.Add("xml", xml, SqlDbType.Xml, int.MaxValue);

            try
            {
                DB.DBHelper.Execute(sql, parameters,ExecuteType.Text);
                DataRowView row = gridRepairIn.GetFocusedRow() as DataRowView;
                if (row != null)
                {
                    ((gridRepairIn.ItemsSource) as DataTable).Rows.Remove(row.Row);
                }
                ClearRepairInfo();
                History();

                if (((gridRepairIn.ItemsSource) as DataTable).Rows.Count > 0)
                {
                    gridViewRepairIn_MouseDown(gridViewRepairIn, null);
                }
                else
                {
                    btnRepairComplete_Click(btnRepairComplete, null);
                }
            }
            catch (Exception ex)
            {
                Component.MessageBox.MyMessageBox.ShowError(ex.Message);
            }
        }

        private void History()
        {
            string sql = @"SELECT Inp_RepairIn.LotSNType,
	   Inp_RepairIn.LotSN,
	   Bas_MO.MOCode,
	   Bas_Order.OrderCode,
	   Bas_Item.ItemCode+'/'+ISNULL(Bas_Item.ItemSpecification,'') AS ItemSpecification,
	   Bas_Line.LineCode+'/'+ISNULL(Bas_Line.LineDesc,'') AS LineDesc,
	   Bas_Res.ResCode+'/'+ISNULL(Bas_Res.ResDesc,'') AS ResDesc,
	   dbo.Ftn_GetWorkflowStationName(Inp_RepairIn.WorkflowStationId) AS WorkflowStationName,
	   Bas_Shift.ShiftCode+'/'+ISNULL(Bas_Shift.ShiftDesc,'') AS ShiftDesc,
	   Set_User.SysUserCode+'/'+ISNULL(Set_User.SysUserName,'') AS UserName,
	   Bas_ErrorCode.ErrorCode+'/'+ISNULL(Bas_ErrorCode.ErrorCodeDesc,'') AS ErrorCodeDesc,
	   dbo.Bas_ErrorCodeGroup.ErrorCodeGroupCode+'/'+ISNULL(Bas_ErrorCodeGroup.ErrorCodeGroupDesc,'') AS ErrorCodeGroupDesc,
	   Bas_ErrorType.ErrorTypeCode+'/'+ISNULL(Bas_ErrorType.ErrorTypeDesc,'') AS ErrorTypeDesc,
	   Inp_RepairIn_Items.CreateDateTime AS InputErrorDateTime,
	   dbo.Bas_ErrorReason.ErrorReasonCode+'/'+ISNULL(Bas_ErrorReason.ErrorReasonDesc,'') AS ErrorReasonDesc,
	   Inp_RepairInfo.ErrorLocation,
	   Inp_RepairInfo.ErrorPoint,
	   Bas_Duty.DUTYCODE+'/'+ISNULL(Bas_Duty.DUTYDESC,'') AS Duty,
	   Bas_Solution.SolutionCode+'/'+ISNULL(Bas_Solution.SolutionDesc,'') AS Solution,
	   Inp_RepairInfo.RepairContent,
	   Inp_RepairInfo.Note AS RepairNote,
	   repairRes.ResCode+'/'+ISNULL(repairRes.ResDesc,'') AS RepairResDesc,
	   repairUser.SysUserCode+'/'+ISNULL(repairUser.SysUserName,'') AS RepairUserName,
	   Inp_RepairInfo.CreateDateTime AS RepairDateTime,
	   dbo.Ftn_GetStatusName(Inp_RepairIn.[Status],'RepairStatusType') AS [Status],
	   CASE WHEN ISNULL(Inp_RepairIn.IsRollbackWorkflow,0)=0 THEN NULL ELSE Bas_Workflow.WorkflowCode+'/'+ISNULL(Bas_Workflow.WorkflowDesc,'') END AS RollbackWorkflowName,
	   CASE WHEN ISNULL(Inp_RepairIn.IsRollbackStation,0)=0 THEN NULL ELSE dbo.Ftn_GetWorkflowStationName(Inp_RepairIn.RollbackStationId) END AS RollbackStationName,
	   (
			stuff((SELECT ISNULL(MaterialSN,'')+','+CAST(CAST(ISNULL(Quantity,0) AS DECIMAL(18,2)) AS NVARCHAR(50))+','+ISNULL(Reason,'')+'|'
			FROM dbo.Inp_RepairInfo_Material  WITH(NOLOCK) WHERE RepairInfoId=Inp_RepairInfo.RepairInfoId
			FOR XML PATH('')),1,1,'')
	   )AS ReplaceMaterialSN
FROM dbo.Inp_RepairInfo  WITH(NOLOCK) 
LEFT JOIN dbo.Inp_RepairIn_Items  WITH(NOLOCK) ON dbo.Inp_RepairIn_Items.RepairIn_ItemsId = dbo.Inp_RepairInfo.RepairIn_ItemsId
LEFT JOIN dbo.Inp_RepairIn  WITH(NOLOCK) ON dbo.Inp_RepairIn.RepairInId = dbo.Inp_RepairInfo.RepairInId
LEFT JOIN dbo.Bas_ErrorCode  WITH(NOLOCK) ON Inp_RepairInfo.ErrorCodeId=dbo.Bas_ErrorCode.ErrorCodeId
LEFT JOIN dbo.Bas_ErrorCodeGroup  WITH(NOLOCK) ON dbo.Bas_ErrorCodeGroup.ErrorCodeGroupId = dbo.Bas_ErrorCode.ErrorCodeGroupId
LEFT JOIN dbo.Bas_ErrorType  WITH(NOLOCK) ON Bas_ErrorCode.ErrorTypeId=Bas_ErrorType.ErrorTypeId
LEFT JOIN dbo.Bas_ErrorReason  WITH(NOLOCK) ON Inp_RepairInfo.ErrorReasonId=Bas_ErrorReason.ErrorReasonId
LEFT JOIN dbo.Bas_Duty  WITH(NOLOCK) ON dbo.Bas_Duty.DUTYID = dbo.Inp_RepairInfo.DutyId
LEFT JOIN dbo.Bas_Solution  WITH(NOLOCK) ON dbo.Bas_Solution.SolutionId = dbo.Inp_RepairInfo.SolutionId
LEFT JOIN dbo.Bas_MO  WITH(NOLOCK) ON Inp_RepairInfo.MOId=Bas_MO.MOId
LEFT JOIN dbo.Bas_OrderDetail  WITH(NOLOCK) ON Bas_MO.OrderDetailId=Bas_OrderDetail.OrderDetailId
LEFT JOIN dbo.Bas_Order  WITH(NOLOCK) ON dbo.Bas_Order.OrderId = dbo.Bas_OrderDetail.OrderId
LEFT JOIN dbo.Inp_Lot  WITH(NOLOCK) ON Inp_RepairInfo.LotId=Inp_Lot.LotId
LEFT JOIN dbo.Bas_Item  WITH(NOLOCK) ON dbo.Bas_Item.ItemId = dbo.Inp_RepairIn.ItemId
LEFT JOIN dbo.Bas_Line  WITH(NOLOCK) ON Inp_RepairIn.LineId=Bas_Line.LineId
LEFT JOIN dbo.Bas_Res  WITH(NOLOCK) ON Bas_Res.ResId=Inp_RepairIn.ResId
LEFT JOIN dbo.Bas_Shift  WITH(NOLOCK) ON Inp_RepairIn.ShiftId=Bas_Shift.ShiftId
LEFT JOIN dbo.Set_User  WITH(NOLOCK) ON dbo.Set_User.SysUserId = dbo.Inp_RepairIn.CreateUserId
LEFT JOIN dbo.Bas_Res  repairRes WITH(NOLOCK) ON repairRes.ResId=Inp_RepairInfo.ResId
LEFT JOIN dbo.Set_User repairUser WITH(NOLOCK) ON repairUser.SysUserId = dbo.Inp_RepairInfo.CreateUserId
LEFT JOIN dbo.Bas_Workflow  WITH(NOLOCK) ON Inp_RepairIn.RollbackWorkflowId=Bas_Workflow.WorkflowId
WHERE Inp_RepairIn.LotId=@LotId
ORDER BY Inp_RepairInfo.CreateDateTime
";
            Parameters parameters = new Parameters().Add("LotId", LotId);

            Component.MaskBusy.Busy(gh, string.Format("正在查询历史记录"), LotSN);
            System.Threading.Tasks.Task<DataTable>.Factory.StartNew(() =>
            {
                return DB.DBHelper.GetDataTable(sql, parameters, ExecuteType.Text);
            }).ContinueWith(bi =>
            {
                if (bi.Result != null)
                {
                    Dispatcher.Invoke(new Action(() =>
                    {
                        gridHistory.ItemsSource = bi.Result;
                        if (bi.Result.Rows.Count > 0)
                        {
                            (gridHistory.View as DevExpress.Xpf.Grid.TableView).FocusedRowHandle = gridHistory.GetRowHandleByListIndex(bi.Result.Rows.Count - 1);
                        }
                    }));
                }
                Component.MaskBusy.Hide(gh);
            });
        }

        private void btnRepairComplete_Click(object sender, RoutedEventArgs e)
        {
            if (!IsRepair)
            {
                return;
            }
            if (!RepairInId.HasValue)
            {
                return;
            }
            if (gridRepairIn.ItemsSource != null && (gridRepairIn.ItemsSource as DataTable).Rows.Count > 0)
            {
                if (!ckbIsScrape.IsChecked.Value && !ckbIsErrorInStore.IsChecked.Value)
                {
                    Component.MessageBox.MyMessageBox.ShowError("产品还有不良代码没有维修，请先维修完所有不良代码！");
                    return;
                }
            }

            if (Component.MessageBox.MyMessageBox.Show(string.Format("确定维修完成吗？", tbRepairError.Text), "提示",
                     MessageBoxButton.OKCancel, MessageBoxImage.Warning) == System.Windows.MessageBoxResult.Cancel)
            {
                return;
            }

            bool IsScrap = ckbIsScrape.IsChecked.Value;
            bool IsErrorInStore = ckbIsErrorInStore.IsChecked.Value;

            bool IsRollbackWorkflow = true;//ckbReWorkflow.IsChecked.Value 不允许维修人员修改工作流
            long? RollbackWorkflowId = WorkflowId.Value;//cmbWorkflow.Value == null ? null : (long?)long.Parse(cmbWorkflow.Value.ToString())
            
            bool IsRollbackStation = ckbReStation.IsChecked.Value;
            long? RollbackStationId = cmbStation.Value == null ? null : (long?)long.Parse(cmbStation.Value.ToString());

            string commont = "";
            if (IsScrap)
            {
                commont = "报废";
            }
            else if (IsErrorInStore)
            {
                commont = "不良入库";
            }
            else if (IsRollbackWorkflow)
            {
                commont = "重新指定工作流";
            }
            else if (IsRollbackStation)
            {
                commont = "重新指定工序";
            }

            if (IsRollbackWorkflow)
            {
                if (!IsRollbackStation)
                {
                    Component.MessageBox.MyMessageBox.ShowError("请指定返回工序！");
                    ckbReStation.IsChecked = true;
                    return;
                }

                if (!RollbackWorkflowId.HasValue)
                {
                    Component.MessageBox.MyMessageBox.ShowError("请选择工作流！");
                    return;
                }
            }
            if (IsRollbackStation)
            {
                if (!RollbackStationId.HasValue)
                {
                    Component.MessageBox.MyMessageBox.ShowError("请选择工序！");
                    return;
                }
            }

            Parameters parameters = new Parameters()
            .Add("LotId", LotId)
            .Add("ResId", Framework.App.Resource.ResourceId)
            .Add("LineId", Framework.App.Resource.LineId)
            .Add("ShiftTypeId", Framework.App.Resource.ShiftTypeId)
            .Add("UserId", Framework.App.User.UserId)
            .Add("OPId", Framework.App.Resource.StationId)
            .Add("RepairInId", RepairInId.Value)
            .Add("IsScrap", IsScrap)
            .Add("IsErrorInStore", IsErrorInStore)
            .Add("WorkflowId", WorkflowId)
            .Add("IsRollbackWorkflow", IsRollbackWorkflow)
            .Add("IsRollbackStation", IsRollbackStation)
            .Add("RollbackWorkflowId", RollbackWorkflowId)
            .Add("RollbackStationId", RollbackStationId)
            .Add("PluginId", PluginId)
            .Add("Comment", commont)
            .Add("Return_Message", null, SqlDbType.NVarChar, int.MaxValue, ParameterDirection.Output)
            .Add("return_value", null, SqlDbType.NVarChar, int.MaxValue, ParameterDirection.ReturnValue);

            string sql = "Prd_Inp_Lot_RepairComplete ";

            try
            {
                parameters = DB.DBHelper.ExecuteParameters(sql, parameters, ExecuteType.StoredProcedure);
                if (parameters["return_value"] != DBNull.Value && parameters["return_value"] != null && int.Parse(parameters["return_value"].ToString()) != 1)
                {
                    Component.MessageBox.MyMessageBox.ShowError(parameters["Return_Message"].ToString());
                    return;
                }
                Component.MessageBox.MyMessageBox.Show(parameters["Return_Message"].ToString());
                Clear(true);
                tbSN.Text = "";
                tbSN.SetFoucs();
            }
            catch (Exception ex)
            {
                Component.MessageBox.MyMessageBox.ShowError(ex.Message);
                return;
            }

        }
    }
}

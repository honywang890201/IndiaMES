﻿using Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WinAPI;
using System.Diagnostics;

namespace BoxPrint_M
{
    /// <summary>
    /// UserControl1.xaml 的交互逻辑
    /// </summary>
    public partial class UserControl1 : Component.Controls.User.UserVendor
    {
        private DataRowView SelectRow = null;
        private string Header = null;
        private long OrderNumber =-1;
        string LasetISN = null;
        string[] Number = new string[32]{"0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F","G","H","J","K","L","M","N","P","Q","R","S","T","W","X","Y","Z"};
        DataTable table=null;
        long StartSerialnumber = 0;
        public UserControl1(Framework.SystemAuthority authority) :
            base(authority)
        {
            InitializeComponent();
            root.Background = new ImageBrush(WinAPI.File.ImageHelper.ConvertToImageSource(Component.App.BackgroudImage));

        }
        private void UserVendor_Loaded(object sender, RoutedEventArgs e)
        {
           Time.Content= DateTime.Now.ToString("yyyy-MM-dd");
          
           // Button_Click(null,null);
        }
        public void Print(DataSet set)
        {
           
        }
        public void AddMessage(string message, bool isError)
        {
        }
        private void btnFillBoxSN_Click(object sender, RoutedEventArgs e)
        {
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //MessageBox.Show("调试", "0", MessageBoxButton.OK, MessageBoxImage.Error);
            Component.Windows.MOSelector selector = new Component.Windows.MOSelector(MenuId);
            selector.Owner = Component.App.Portal;
            MessageBox.Show("调试", "1", MessageBoxButton.OK, MessageBoxImage.Error);
            if (selector.ShowDialog().Value)
            {

                MessageBox.Show("调试", "2", MessageBoxButton.OK, MessageBoxImage.Error);
                string sql = @"SELECT [MOId]
      ,[MOCode]
      ,[SpecSheet]
  FROM [ForTestProd].[dbo].[Bas_MO] WHERE Bas_MO.MOId=@MOId";
                Parameters parameters = new Parameters();
                parameters.Add("MOId", selector.moId);
                OrderNumber = selector.moId;
                try
                {
                    table = DB.DBHelper.GetDataTable(sql, parameters, ExecuteType.Text, null, true);
                    if (table.Rows.Count < 1)
                    {
                        MessageBox.Show("工单错误", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                    SelectRow = table.DefaultView[0];
                    OrderNum.Content = "      订单号为:"+SelectRow["MOCode"].ToString()+ "      固定头为:" + SelectRow["SpecSheet"].ToString();
                    Header= SelectRow["SpecSheet"].ToString();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
                
            }
        }
        //只允许输入数字，字母或其他数据不允许
        private void TextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key >= Key.D0 && e.Key <= Key.D9 || e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9)
            {
                e.Handled = false;
            }
            else e.Handled = true;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if ((DateTime.Compare(DaPicker.SelectedDate.Value, DateTime.Today)>0)|| (DateTime.Compare(DaPicker.SelectedDate.Value, DateTime.Today)==0))
            {
                int DataLenth = 0;
                if (OrderNumber != -1 && Quantity.Text != string.Empty)
                {
                    table.Clear();
                    Result.ItemsSource = table.DefaultView;
                    string sql = @"SELECT TOP " + Quantity.Text + @"
                 [Mac]
                ,[DeviceSerialNumber]
                ,[CISN]
                ,[DSN]
                ,[STBNO]
            FROM [ForTestProd].[dbo].[Bas_MO_Mac] where CISN IS NULL AND MOId=@MOId";
                    Parameters parameters = new Parameters();
                    parameters.Add("MOId", OrderNumber);
                    try
                    {
                        table = DB.DBHelper.GetDataTable(sql, parameters, ExecuteType.Text, null, true);
                        if (table.Rows.Count < 1)
                        {
                            MessageBox.Show("所选工单没有导入个性化数据或ISN已经全部打印完成，请核对后再操作", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                            return;
                        }
                        DataLenth = table.Rows.Count;
                        if (Convert.ToInt32(Quantity.Text) > DataLenth)
                        {
                            if (MessageBoxResult.No == MessageBox.Show("此订单中剩余未打印的数量小于您输入的数量，请确认是否打印！！！！", "确认打印信息!!!", MessageBoxButton.YesNo, MessageBoxImage.Question))
                            {
                                return;
                            }
                        }
                        //DaPicker.SelectedDate.Value.ToString("yy").Substring(1);
                        StartSerialnumber = FindLatestNumber(OrderNumber);
                        if (!DateCompare(DaPicker.SelectedDate.Value.ToString("yyyy-MM-dd")))
                        {
                            StartSerialnumber = 0;
                        }
                        table.Columns.Add("SN", typeof(int));
                        for (int i = 0; i < DataLenth; i++)
                        {
                            table.Rows[i]["SN"] = (i + 1).ToString();
                            table.Rows[i]["CISN"] = Header + Number[Convert.ToInt32(DaPicker.SelectedDate.Value.ToString("yy").Substring(1))] + Number[Convert.ToInt32(DaPicker.SelectedDate.Value.ToString("MM"))] +
                            Number[Convert.ToInt32(DaPicker.SelectedDate.Value.ToString("dd"))] + "4" + Number[Convert.ToInt32(LineCode.Text)] + IntToi32(i + StartSerialnumber + 1).PadLeft(4, '0');
                        }
                        Result.ItemsSource = table.DefaultView;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                } else
                {
                    MessageBox.Show("还没有选择订单号，请确认后再生成");
                }
            }
            else
            {
                MessageBox.Show("根据协定，不允许打印之前日期的ISN，请重新确认后再次生成","错误",MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            string result1 = @"C:\测试文件.txt";//结果保存到桌面
            FileStream fs = new FileStream(result1, FileMode.Create);
            StreamWriter wr = null;
            wr = new StreamWriter(fs);
            int  Lenth = table.Rows.Count; 
            for (int i = 0; i <Lenth; i++)
            {
                SelectRow = table.DefaultView[i];
                if (SelectRow["Mac"].ToString() != string.Empty)
                {
                    string sql = @"UPDATE [ForTestProd].[dbo].[Bas_MO_Mac] SET CISN='" + SelectRow["CISN"] + "' WHERE Mac='" + SelectRow["Mac"] + "' AND MOId=@MOId";
                    Parameters parameters = new Parameters();
                    parameters.Add("MOId", OrderNumber);
                    DataTable mytable = DB.DBHelper.GetDataTable(sql, parameters, ExecuteType.Text, null, true);
                    //if (mytable.Rows.Count < 1)
                    //{
                    //    MessageBox.Show("工单错误", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                    //    return;
                    //}
                    wr.WriteLine(SelectRow["Mac"] + "," + SelectRow["DeviceSerialNumber"] + "," + SelectRow["CISN"] + "," + SelectRow["DSN"] + "," + SelectRow["STBNO"]);

                }
            }
           
            wr.Close();
        }
        
        public bool DateCompare(string str)
        {
            int YearIndex =Convert.ToInt16( str.Substring(3, 1));
            int MonthIndex = Convert.ToInt16(str.Substring(5, 2));
            int DayIndex = Convert.ToInt16(str.Substring(8, 2));
            //string a = LasetISN.Substring(11, 1);
            //string b = LasetISN.Substring(12, 1);
            //string c = LasetISN.Substring(13, 1);
            if (Number[YearIndex]== LasetISN.Substring(11,1)&&
               Number[MonthIndex] == LasetISN.Substring(12, 1) &&
               Number[DayIndex] == LasetISN.Substring(13, 1))
            {
                return true;
            }
            
            return false;
        }
        public static string IntToi32(long xx)
        {
            string a = "";
            while (xx >= 1)
            {
                int index = Convert.ToInt16(xx - (xx / 32) * 32);
                a = Base64Code[index] + a;
                xx = xx / 32;
            }
            return a;
        }
        public static Dictionary<int, string> Base64Code = new Dictionary<int, string>() {
            {   0  ,"0"}, {   1  ,"1"}, {   2  ,"2"}, {   3  ,"3"}, {   4  ,"4"}, {   5  ,"5"}, {   6  ,"6"}, {   7  ,"7"}, {   8  ,"8"}, {   9  ,"9"},
            {   10  ,"A"}, {   11  ,"B"}, {   12  ,"C"}, {   13  ,"D"}, {   14  ,"E"}, {   15  ,"F"}, {   16  ,"G"}, {   17  ,"H"}, {   18  ,"J"}, {   19  ,"K"},
            {   20  ,"L"}, {   21  ,"M"}, {   22  ,"N"}, {   23  ,"P"}, {   24  ,"Q"}, {   25  ,"R"}, {   26  ,"S"}, {   27  ,"T"}, {   28  ,"W"}, {   29  ,"X"},
            {   30  ,"Y"}, {   31  ,"Z"}, {   32  ,"w"}, {   33  ,"x"}, {   34  ,"y"}, {   35  ,"z"}, {   36  ,"A"}, {   37  ,"B"}, {   38  ,"C"}, {   39  ,"D"},
            {   40  ,"E"}, {   41  ,"F"}, {   42  ,"G"}, {   43  ,"H"}, {   44  ,"I"}, {   45  ,"J"}, {   46  ,"K"}, {   47  ,"L"}, {   48  ,"M"}, {   49  ,"N"},
            {   50  ,"O"}, {   51  ,"P"}, {   52  ,"Q"}, {   53  ,"R"}, {   54  ,"S"}, {   55  ,"T"}, {   56  ,"U"}, {   57  ,"V"}, {   58  ,"W"}, {   59  ,"X"},
            {   60  ,"Y"}, {   61  ,"Z"}, {   62  ,"-"}, {   63  ,"_"},
        };

        private void LineCode_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key >= Key.D0 && e.Key <= Key.D9 || e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9)
            {
                e.Handled = false;
            }
            else e.Handled = true;
        }
        public long CalculateSerial(string str)
        {
            long Result = 0,DigitFour=0,DigitThree=0,DigitTwo=0,DigitOne=0;
            string TempString=str.Substring(16);
            string Th = TempString.Substring(0, 1);
            string Hu = TempString.Substring(1, 1);
            string Sh = TempString.Substring(2, 1);
            string Ge = TempString.Substring(3, 1);
            DigitFour = FindIndex(Th);
            DigitThree = FindIndex(Hu);
            DigitTwo = FindIndex(Sh);
            DigitOne = FindIndex(Ge);
            Result = (DigitFour * 32 * 32 * 32) + (DigitThree * 32 * 32) + (DigitTwo * 32) + DigitOne;
            return Result;
        }
        public long FindIndex(string str)
        {
            for(int i=0;i<32;i++)
            {
                if(str==Number[i])
                {
                    return i;
                }
            }
            return -1;
        }

        public long FindLatestNumber(long str)
        {
            DataTable mdata = null;
            DataRowView mSelectRow = null;
            string sql = @"SELECT TOP 1 [CISN] FROM [ForTestProd].[dbo].[Bas_MO_Mac] WHERE CISN IS NOT NULL AND MOId="+ str .ToString()+ " ORDER BY Mac DESC";
            Parameters parameters = new Parameters();
            //parameters.Add("MOId", str);
            try
            {
                mdata = DB.DBHelper.GetDataTable(sql, parameters, ExecuteType.Text, null, true);
                if (mdata.Rows.Count < 1)
                {
                    //选择的订单没有导入过ISN，返回0
                    return 0;
                }
                mSelectRow = mdata.DefaultView[0];
                LasetISN = mSelectRow["CISN"].ToString();
                return CalculateSerial(mSelectRow["CISN"].ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                return 0;
            }
        }

        private void DropTest(object sender, DragEventArgs e)
        {

        }
    }

}

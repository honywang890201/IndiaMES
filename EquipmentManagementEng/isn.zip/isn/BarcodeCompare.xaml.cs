﻿using Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WinAPI;
using System.Diagnostics;
using System.Collections;
using System.Threading;

namespace BoxPrint_BarcodeCompare
{
    /// <summary>
    /// BarcodeCompare.xaml 的交互逻辑
    /// </summary>
    public partial class BarcodeCompare : Component.Controls.User.UserVendor
    {
        //从二维码获取
        const string MES_STAR_SCAN_MAC = "MAC";
        const string MES_STAR_SCAN_SN = "SN";
        const string MES_STAR_SCAN_CHIPID = "CHIPID";

        private static readonly object Lock = new object();
        private long OrderNumber = -1;
        private DataTable table = null;
        private DataRowView SelectRow = null;
        private string Header = null;

        public BarcodeCompare(Framework.SystemAuthority systemAuthority)
        {
            InitializeComponent();
            root.Background = new ImageBrush(WinAPI.File.ImageHelper.ConvertToImageSource(Component.App.BackgroudImage));
            OneCode.Focus();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //OrderTip.Content = "order" + "compare";
            Button_Click2(sender,e);
        }
        private void Button_Click2(object sender, RoutedEventArgs e)
        {
            Component.Windows.MOSelector selector = new Component.Windows.MOSelector(MenuId);
            selector.Owner = Component.App.Portal;
            if (selector.ShowDialog().Value)
            {
                string sql = @"SELECT [MOId]
                  ,[MOCode]
                  ,[SpecSheet]
                    FROM [ForTestProd].[dbo].[Bas_MO] WHERE Bas_MO.MOId=@MOId";
                Parameters parameters = new Parameters();
                parameters.Add("MOId", selector.moId);
                OrderNumber = selector.moId;
                try
                {
                    table = DB.DBHelper.GetDataTable(sql, parameters, ExecuteType.Text, null, true);
                    if (table.Rows.Count < 1)
                    {
                        MessageBox.Show("工单错误", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                    SelectRow = table.DefaultView[0];
                    OrderNum.Content = "      订单号为:" + SelectRow["MOCode"].ToString() + "      固定头为:" + SelectRow["SpecSheet"].ToString();
                    Header = SelectRow["SpecSheet"].ToString();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

            }
        }

        private void UserVendor_Loaded(object sender, RoutedEventArgs e)
        {

        }
        private void CodeKeyDown(object sender, KeyEventArgs e)
        {
            //Debug("key down");
        }

        private void CodeKeyUp(object sender, KeyEventArgs e)
        {
            if(e.Key == Key.Enter)
            {
                if(OrderNumber == -1)
                {
                    Debug("请选择订单");
                    return;
                }
                System.Windows.Documents.FlowDocument doc;
                if (OneCode.IsFocused)
                {
                    if (OneCode.Text == String.Empty)
                    {
                        Debug("请扫描机身二维码");
                    }
                    else
                    {
                        TwoCode.Focus();
                        doc = TwoCode.Document;
                        doc.Blocks.Clear();
                    }
                    return;
                }else if(!TwoCode.IsFocused)
                {
                    Debug("请扫描盒子界面二维码");
                    return;
                }
                //二维码
                string strOne,strTwo,temp;
                string strOneSub1, strOneSub2;
                Dictionary<string, string> m_mapMesScan = new Dictionary<string, string>();

                m_mapMesScan.Clear();
                strOne = OneCode.Text;
                strOne.Trim();
                strTwo = new TextRange(TwoCode.Document.ContentStart,
                               TwoCode.Document.ContentEnd).Text;
				
                strOneSub1 = strOne.Substring(0,strOne.IndexOf('_'));
                strOneSub2 = strOne.Substring(strOne.IndexOf('_')+1,strOne.Length - strOneSub1.Length - 1);
				
                MesScanParse(strTwo, ref m_mapMesScan);
                if (m_mapMesScan.Count() < 5)
                {
          			return;
                }
           
                if (String.Compare(strOneSub1,m_mapMesScan[MES_STAR_SCAN_MAC],true) != 0 
					|| String.Compare(strOneSub2,m_mapMesScan[MES_STAR_SCAN_SN],true) != 0)
                {
                    temp = "对比数据有误," + strOneSub1 + "," + strOneSub2 + "; " + m_mapMesScan[MES_STAR_SCAN_MAC] + "," + m_mapMesScan[MES_STAR_SCAN_SN];
                    Debug(temp);
                    OneCode.Clear();
                    doc = TwoCode.Document;
                    doc.Blocks.Clear();
                    OneCode.Focus();
                    return;
                }

                Parameters parameters = new Parameters();
                parameters.Add("LotSN", strOneSub1);//mac
                parameters.Add("GetCode", m_mapMesScan[MES_STAR_SCAN_CHIPID]);//chipid
                parameters.Add("MOId", OrderNumber);
                parameters.Add("LineId", Framework.App.Resource.LineId);
                parameters.Add("ResId", Framework.App.Resource.ResourceId);
                parameters.Add("ShiftTypeId", Framework.App.Resource.ShiftTypeId);
                parameters.Add("UserId", Framework.App.User.UserId);
                parameters.Add("OPId", Framework.App.Resource.StationId);
                parameters.Add("PluginId", PluginId);
                parameters.Add("Comment", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                parameters.Add("FocusedParam", null, SqlDbType.NVarChar, 50,ParameterDirection.Output);
                parameters.Add("Return_Message", null, SqlDbType.NVarChar, int.MaxValue, ParameterDirection.Output);

                Result<Parameters, DataSet> result = null;
                try
                {
                    result = DB.DBHelper.ExecuteParametersSource("Prd_Inp_BindingProductSN", parameters, ExecuteType.StoredProcedure);
                }
                catch (Exception ex)
                {
                    Debug(ex.Message);
                    OneCode.Clear();
                    doc = TwoCode.Document;
                    doc.Blocks.Clear();
                    OneCode.Focus();
                    return;
                }

                if (result.HasError)
                {
                    Debug(result.Message);
                    OneCode.Clear();
                    doc = TwoCode.Document;
                    doc.Blocks.Clear();
                    OneCode.Focus();
                    return;
                }

                if ((int)result.Value1["Return_Value"] != 1)
                {
                    //uc.AddMessage(result.Value1["Return_Message"].ToString(), true);
                    Debug(result.Value1["Return_Message"].ToString());
                    OneCode.Clear();
                    doc = TwoCode.Document;
                    doc.Blocks.Clear();
                    OneCode.Focus();
                    return;
                }
                else
                {
                    Debug("");
                    OneCode.Clear();
                    doc = TwoCode.Document;
                    doc.Blocks.Clear();
                    OneCode.Focus();
                }
            }
        }

        private void Debug(string msg)
        {
            ErrorTip.Content = msg;
            if (msg == String.Empty)
            {
                CompareResultTip.Content = "Success";
                CompareResultTip.Foreground = new SolidColorBrush(Colors.Green);
            }
            else
            {
                CompareResultTip.Content = "Fail";
                CompareResultTip.Foreground = new SolidColorBrush(Colors.Red);
            }
        }

        private ArrayList SplitCString(string strSource, string ch)
        {
            ArrayList alData = new ArrayList();
            char[] charSplit = ch.ToCharArray();
            string[] sArray1 = strSource.Split(charSplit);
            foreach (string str in sArray1)
            {
                alData.Add(str.ToString());
            }
            return alData;
        }
        /***************

        对扫描的数据进行解析

        ****************/
        private bool MesScanParse(string src, ref Dictionary<string, string> m_mapMesScan)
        {
            string str, temp, key;
            int pos = 0;
            src.ToUpper();
            src = src.Replace(" ", "");
			
            ArrayList alData = new ArrayList();
            alData = SplitCString(src, "\r\n"); 
            //vector<string> data = SplitCString(src, "\r\n");
            for (int i = 0; i < (int)alData.Count; i++)
            {
                if (alData[i].ToString() == String.Empty)
                {
                    continue;
                }
                temp = alData[i].ToString();
                pos = temp.IndexOf("=");
                key = temp.Substring(0,pos);
                if (key.ToString() == String.Empty)
                {
                    Debug("key is empty");
                    continue;
                }
                str = temp.Substring(pos+1,temp.Length - pos - 1);
                str.Trim();
                key.Trim();
                key.ToUpper();
                m_mapMesScan[key] = str;
                temp = key + "=" + str;
           //     Debug(temp);
            }
            return true;
        }
    }


}
